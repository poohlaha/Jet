<script>
</script>

<h1>ℹ️ About</h1>
<p>This page is loaded from <code>src/pages/About.svelte</code>.</p>