<script>
</script>

<h2>Welcome to Home Page</h2>
<p>This is the content of Home.</p>