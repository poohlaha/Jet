/**
 * @fileOverview 入口文件
 * @date 2025-11-10
 * @author poohlaha
 * @description
 */
import { startApplication } from './browser';

startApplication();