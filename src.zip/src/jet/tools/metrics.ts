/**
 * @fileOverview 度量统计
 * @date 2025-11-07
 * @author poohlaha
 * @description 提供 metrics 接口（记录事件、计时）与一个 console 实现 consoleMetrics，用于性能度量与事件统计
 */

export interface Metrics {
  recordEvent(name: string, payload?: any): void;
  asyncTime<T>(name: string, fn: () => Promise<T> | T): Promise<T>;
}

export const consoleMetrics: Metrics = {
  // 记录事件
  recordEvent: (name, payload) => console.log('[metrics]', name, payload),

  // 对某段异步/同步操作计时并返回结果(内部打印耗时、异常)
  async asyncTime(name, fn) {
    const t0 = Date.now();
    try {
      const r = await fn();
      console.log('[metrics.time]', 'color:green;', name, `${Date.now() - t0}ms`);
      return r;
    } catch (e) {
      console.log('[metrics.time]', 'color:red;', name, 'failed', `${Date.now() - t0}ms`);
      throw e;
    }
  }
}
