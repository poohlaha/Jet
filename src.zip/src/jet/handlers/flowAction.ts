/**
 * @fileOverview 处理 flowAction（导航相关）的业务逻辑
 * @date 2025-11-10
 * @author poohlaha
 * @description 根据 action.payload.route 返回不同的 Page 或返回另一个 ActionModel（用于委托处理，例如打开外部 URL）
 */
import {Dependencies} from "../types";
import {makeFlowIntent} from "../tools/intent";
import {pageHandler} from "./pageHandler";

export const FLOW_ACTION_KIND = 'flowAction';

export async function registerHandler(dependencies: Dependencies) {
    console.log('%c[Jet] Registering FlowActionHandler', 'color:green;');

    const { jet, logger, updateApp } = dependencies;

    let isFirstPage = true;

    /*
    const route = action.payload?.route;
    if (!route || route === '/') {
        return { type: 'home', title: 'Home', welcomeText: 'Welcome to Jet Demo!' };
    }

    if (route === '/article') {
        // 模拟异步延迟
        await new Promise((r) => setTimeout(r, 600));
        return { type: 'article', title: 'Article', content: 'This article was loaded dynamically.' };
    }

    if (route === '/external') {
        // 返回一个新的 ActionModel
        return { $kind: 'externalUrlAction', payload: { url: 'https://example.com' } };
    }

    throw new Error('404: Not found');

     */
    jet.onAction?.(FLOW_ACTION_KIND, async (action: any) => {
        console.log('[JetLite] FlowAction received:', action);

        const route = action.payload?.route || '/';
        const intent = makeFlowIntent(route);

        // 直接调用 pageHandler 获取页面
        const pagePromise = (async () => {
            return await pageHandler({ payload: { route } });
        })();

        // 通知 UI 层更新
        updateApp?.({
            page: pagePromise,
            isFirstPage,
        });

        // 更新浏览器历史
        if (isFirstPage) {
            history.replaceState({ route }, '', route);
        } else {
            history.pushState({ route }, '', route);
        }

        // 监听前进/后退
        window.onpopstate = async (event) => {
            const route = window.location.pathname || '/';
            const intent = makeFlowIntent(route);
            const page = await pageHandler({ payload: { route } });
            updateApp?.({ page: Promise.resolve(page), isFirstPage });
        };

        isFirstPage = false;
    });
}