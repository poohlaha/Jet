/**
 * @fileOverview 处理 externalUrlAction
 * @date 2025-11-10
 * @author poohlaha
 * @description
 */

import {Jet} from "../jet";
import {Logger} from "../tools/logger";

export type Dependencies = {
    jet: Jet;
    logger: Logger;
};

export function registerHandler(dependencies: Dependencies) {
    const { jet, logger } = dependencies;

    /*
    jet.onAction('ExternalUrlAction', async (action: any) => {
        logger.info('received external URL action:', action);
        return 'performed';
    });
     */
}